create
    definer = root@`%` procedure get_messages(IN cid int, IN uid char(36), IN offset int)
BEGIN
    SET @id = NULL;

    SELECT m.`id`
    INTO @id
    FROM `members` m
             JOIN `servers` s ON m.`server_id` = s.`id`
             JOIN `channels` c ON cid = c.`id`
    WHERE m.`user_id` = uid;
    IF (@id IS NULL) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'User is not a member of this server';
    END IF;
    SELECT m.`id`         AS `message_id`,
           m.`user_id`    AS `user_id`,
           m.`timestamp`  AS `timestamp`,
           m.`channel_id` AS `channel_id`,
           m.`text`       AS `message`
    FROM `messages` m
             LEFT JOIN `channels` c ON m.`channel_id` = c.`id`
    WHERE c.`id` = cid
    ORDER BY `timestamp` DESC, `message_id` DESC
    LIMIT 30 OFFSET offset;
END;

