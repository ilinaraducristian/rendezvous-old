create view get_server_data as
select `s`.`id`       AS `server_id`,
       `s`.`name`     AS `server_name`,
       `s`.`user_id`  AS `owner`,
       `g`.`id`       AS `group_id`,
       `g`.`name`     AS `group_name`,
       `g`.`order`    AS `group_order`,
       `c`.`id`       AS `channel_id`,
       `c`.`name`     AS `channel_name`,
       `c`.`group_id` AS `channel_gid`,
       `c`.`type`     AS `channel_type`,
       `c`.`order`    AS `channel_order`,
       `m`.`id`       AS `member_id`,
       `m`.`user_id`  AS `member_uid`,
       `m`.`order`    AS `server_order`
from (((`keycloak`.`servers` `s` left join `keycloak`.`groups` `g` on ((`s`.`id` = `g`.`server_id`))) left join `keycloak`.`channels` `c` on ((
        ((`c`.`group_id` is not null) and (`g`.`id` = `c`.`group_id`)) xor (`s`.`id` = `c`.`server_id`))))
         left join `keycloak`.`members` `m` on ((`s`.`id` = `m`.`server_id`)));

-- comment on column get_server_data.owner not supported: owner

-- comment on column get_server_data.group_order not supported: group order

-- comment on column get_server_data.channel_order not supported: channel order

-- comment on column get_server_data.server_order not supported: user server order preference

