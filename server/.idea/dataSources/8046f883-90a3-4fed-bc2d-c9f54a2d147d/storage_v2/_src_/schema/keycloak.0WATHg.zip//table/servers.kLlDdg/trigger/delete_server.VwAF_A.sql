create definer = root@`%` trigger delete_server
    before delete
    on servers
    for each row
BEGIN
    DELETE FROM `members` WHERE `server_id` = OLD.`id`;
    DELETE `messages`
    FROM `messages`,
         `channels`
    WHERE `channels`.`server_id` = OLD.`id`
      AND `channels`.`type` = 'text'
      AND `messages`.`channel_id` = `channels`.`id`;
    DELETE FROM `channels` WHERE `channels`.`server_id` = OLD.id;
    DELETE FROM `groups` WHERE `groups`.`server_id` = OLD.id;
END;

