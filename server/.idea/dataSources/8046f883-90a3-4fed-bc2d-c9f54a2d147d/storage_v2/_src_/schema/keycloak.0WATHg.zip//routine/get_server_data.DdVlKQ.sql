create
    definer = root@`%` procedure get_server_data(IN sid int, IN uid char(36))
BEGIN
    SET @id = NULL;
    SELECT `id` INTO @id FROM `members` WHERE `server_id` = sid AND `user_id` = uid;
    IF (@id IS NULL) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'User is not a member of this server';
    END IF;
    SELECT * FROM get_server_data WHERE `server_id` = sid;
END;

