create definer = root@`%` trigger insert_channel
    before insert
    on channels
    for each row
BEGIN
    IF (LENGTH(TRIM(NEW.`name`)) = 0) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Channel name must not be empty';
    END IF;
END;

