create definer = root@`%` trigger insert_group
    before insert
    on `groups`
    for each row
BEGIN
    IF (LENGTH(TRIM(NEW.`name`)) = 0) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Group name must not be empty';
    END IF;
END;

