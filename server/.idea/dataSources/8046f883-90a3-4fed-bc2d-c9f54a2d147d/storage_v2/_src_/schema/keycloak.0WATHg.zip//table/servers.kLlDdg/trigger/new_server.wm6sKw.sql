create definer = root@`%` trigger new_server
    after insert
    on servers
    for each row
BEGIN
    INSERT INTO `groups` (`server_id`, `name`) VALUES (NEW.`id`, 'Text channels');
    SET @g1_id = LAST_INSERT_ID();
    INSERT INTO `groups` (`server_id`, `name`, `order`) VALUES (NEW.`id`, 'Voice channels', 1);
    SET @g2_id = LAST_INSERT_ID();
    INSERT INTO `channels` (`server_id`, `group_id`, `type`, `name`) VALUES (NEW.`id`, @g1_id, 'text', 'general');
    INSERT INTO `channels` (`server_id`, `group_id`, `type`, `name`) VALUES (NEW.`id`, @g2_id, 'voice', 'General');
    INSERT INTO `members` (`server_id`, `user_id`) VALUES (NEW.`id`, NEW.`user_id`);
END;

